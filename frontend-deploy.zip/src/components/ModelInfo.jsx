import React from 'react';
import { Database, Layers, CheckCircle2, AlertTriangle, Cpu, Activity, Info } from 'lucide-react';

export default function ModelInfo() {
  const metrics = [
    { label: 'Test Accuracy', value: '84.52%' },
    { label: 'Macro Precision', value: '84.82%' },
    { label: 'Macro Recall', value: '84.52%' },
    { label: 'Macro F1-Score', value: '84.58%' },
  ];

  return (
    <section id="about-model" className="model-info-section">
      <div className="app-container">
        
        <div className="section-header text-center">
          <span className="badge badge-cyan">MODEL ARCHITECTURE & BENCHMARK</span>
          <h2 className="section-title">Inside the Model</h2>
          <p className="section-subtitle">
            Technical specifications, empirical metrics, and research architecture context.
          </p>
        </div>

        <div className="model-info-grid">
          
          {/* Card 1: Technical Overview */}
          <div className="glass-panel model-info-card">
            <div className="card-header-icon">
              <Cpu className="text-cyan" size={24} />
              <h3 className="card-heading">Model Specifications</h3>
            </div>
            
            <ul className="spec-list">
              <li>
                <span className="spec-label">Base Architecture:</span>
                <span className="spec-value">RoBERTa (Robustly Optimized BERT Approach)</span>
              </li>
              <li>
                <span className="spec-label">Task Formulation:</span>
                <span className="spec-value">3-Class Sentence-Pair Sequence Classification</span>
              </li>
              <li>
                <span className="spec-label">Target Classes:</span>
                <span className="spec-value">Invalidate (0), Neutral (1), Support (2)</span>
              </li>
              <li>
                <span className="spec-label">Research Focus:</span>
                <span className="spec-value">Temporal Cues & Evolving Information Fact Verification</span>
              </li>
              <li>
                <span className="spec-label">Experimental Extension:</span>
                <span className="spec-value">Temporal RoBERTa V3 (Time-Aware Features + Supervised Contrastive Loss)</span>
              </li>
            </ul>
          </div>

          {/* Card 2: Empirical Baseline Performance */}
          <div className="glass-panel model-info-card">
            <div className="card-header-icon">
              <Activity className="text-emerald" size={24} />
              <h3 className="card-heading">Baseline Metrics</h3>
            </div>

            <div className="metrics-grid">
              {metrics.map((m) => (
                <div key={m.label} className="metric-box">
                  <span className="metric-number">{m.value}</span>
                  <span className="metric-label">{m.label}</span>
                </div>
              ))}
            </div>

            <div className="metric-note">
              <Info size={14} className="inline-icon text-sky" />
              <span>
                <strong>Note:</strong> These metrics reflect the verified <strong>standard RoBERTa baseline</strong> performance on the experimental test split.
              </span>
            </div>
          </div>

        </div>

        {/* Research Scope & Live Data Disclaimer */}
        <div className="glass-panel scope-disclaimer-card">
          <div className="scope-header">
            <AlertTriangle className="text-amber" size={20} />
            <h4 className="scope-title">Operational Scope & Boundary</h4>
          </div>
          <p className="scope-text">
            This system operates purely as a <strong>closed-world neural classifier</strong>. It evaluates semantic and temporal compatibility between the two user-provided statements based on knowledge representations learned during training. It does <strong>not</strong> perform live internet searches, query external databases, or verify current real-time news events.
          </p>
        </div>

      </div>
    </section>
  );
}
