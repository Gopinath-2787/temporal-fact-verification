import React from 'react';
import { Clock, ShieldCheck, ArrowUp } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToAbout = () => {
    const element = document.getElementById('about-model');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="app-footer">
      <div className="app-container footer-inner">
        
        <div className="footer-brand-col">
          <div className="footer-brand">
            <div className="brand-icon-wrapper sm">
              <Clock size={16} className="icon-clock" />
              <ShieldCheck size={12} className="icon-shield" />
            </div>
            <span className="brand-title">Temporal AI</span>
          </div>
          
          <p className="full-project-title">
            Enhanced Temporal Fact Verification for Evolving Information Using Time-Aware Transformer Learning
          </p>
          <span className="project-category-tag">
            AI & Data Science Research Project
          </span>
        </div>

        <div className="footer-nav-col">
          <h4 className="footer-heading">Quick Links</h4>
          <button onClick={scrollToAbout} className="footer-link">
            About Model & Baseline Metrics
          </button>
          <button onClick={scrollToTop} className="footer-link">
            Back to Top <ArrowUp size={12} />
          </button>
        </div>

      </div>

      <div className="footer-bottom-bar">
        <div className="app-container footer-bottom-inner">
          <p className="footer-disclaimer-note">
            Research prototype — predictions require human verification.
          </p>
          <p className="footer-copyright">
            © {new Date().getFullYear()} Temporal AI Research Project. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
