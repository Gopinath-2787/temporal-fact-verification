import React, { useState } from 'react';
import { Clock, ShieldCheck, RefreshCw, Menu, X, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Navbar({ health, checkingHealth, onRefreshHealth }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="navbar-header">
      <div className="app-container navbar-inner">
        {/* Brand Logo */}
        <div className="navbar-brand" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="brand-icon-wrapper">
            <Clock className="icon-clock" size={20} />
            <ShieldCheck className="icon-shield" size={16} />
          </div>
          <div className="brand-text-container">
            <span className="brand-title">Temporal AI</span>
            <span className="brand-subtitle">Fact Verification</span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="desktop-nav">
          <button onClick={() => scrollToSection('workspace')} className="nav-link">
            Verify
          </button>
          <button onClick={() => scrollToSection('how-it-works')} className="nav-link">
            How It Works
          </button>
          <button onClick={() => scrollToSection('about-model')} className="nav-link">
            About Model
          </button>
        </nav>

        {/* API Status Indicator */}
        <div className="status-area">
          <div 
            className={`status-badge ${health.isOnline ? 'badge-online' : 'badge-offline'}`}
            title={health.isOnline ? `Backend API connected. Model loaded: ${health.modelLoaded}` : `Backend API disconnected (${health.error || 'Server unavailable'})`}
          >
            <span className={`dot-indicator ${health.isOnline ? 'dot-online' : 'dot-offline'}`} />
            <span className="status-text">
              {health.isOnline ? (health.modelLoaded ? 'API Connected' : 'API Online (No Model)') : 'API Offline'}
            </span>
            <button 
              onClick={onRefreshHealth} 
              disabled={checkingHealth} 
              className="refresh-btn"
              title="Refresh connection status"
            >
              <RefreshCw size={12} className={checkingHealth ? 'spinner' : ''} />
            </button>
          </div>

          {/* Mobile menu toggle */}
          <button 
            className="mobile-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="mobile-drawer">
          <button onClick={() => scrollToSection('workspace')} className="mobile-nav-link">
            Verify Workspace
          </button>
          <button onClick={() => scrollToSection('how-it-works')} className="mobile-nav-link">
            How It Works
          </button>
          <button onClick={() => scrollToSection('about-model')} className="mobile-nav-link">
            About Model & Research
          </button>
        </div>
      )}
    </header>
  );
}
