import React from 'react';
import { ArrowUpRight, Sparkles, Clock, Calendar, CheckSquare, XSquare } from 'lucide-react';

const EXAMPLES = [
  {
    id: 'support-match',
    category: 'Matching & Support',
    label: 'Sequential Event Support',
    icon: <CheckSquare size={16} className="text-emerald" />,
    sentence1: "SpaceX launched its Falcon 9 rocket successfully in March 2023.",
    sentence2: "The March 2023 Falcon 9 mission by SpaceX reached target orbit as planned."
  },
  {
    id: 'negation-contradiction',
    category: 'Negation Contradiction',
    label: 'Direct Fact Invalidation',
    icon: <XSquare size={16} className="text-rose" />,
    sentence1: "The company reported a profit of $50 million in Q3 2022.",
    sentence2: "The company suffered a net loss and zero profit in Q3 2022."
  },
  {
    id: 'role-change',
    category: 'Role & Time Transition',
    label: 'Temporal Role Shift',
    icon: <Clock size={16} className="text-sky" />,
    sentence1: "Ravi served as the Chief Executive Officer of TechCorp throughout 2020.",
    sentence2: "Priya took over as the new Chief Executive Officer of TechCorp in 2025."
  },
  {
    id: 'date-reasoning',
    category: 'Date & Context Reasoning',
    label: 'Chronological Context',
    icon: <Calendar size={16} className="text-violet" />,
    sentence1: "The international climate summit commenced on November 15, 2021 in Paris.",
    sentence2: "Delegates gathered in Paris for the climate summit on Nov 15, 2021."
  }
];

export default function ExampleGallery({ onSelectExample }) {
  return (
    <section className="examples-section">
      <div className="app-container">
        <div className="section-header text-center">
          <span className="badge badge-cyan">EXPLORE TEST PAIRS</span>
          <h2 className="section-title">Try Example Statements</h2>
          <p className="section-subtitle">
            Select a sample sentence pair below to populate the workspace inputs, then run the model to inspect its prediction.
          </p>
        </div>

        <div className="examples-grid">
          {EXAMPLES.map((ex) => (
            <div 
              key={ex.id}
              className="glass-panel glass-panel-interactive example-card"
              onClick={() => onSelectExample(ex.sentence1, ex.sentence2)}
            >
              <div className="example-card-top">
                <span className="example-category">
                  {ex.icon}
                  {ex.category}
                </span>
                <span className="example-action-hint">
                  Use Pair <ArrowUpRight size={14} />
                </span>
              </div>

              <h3 className="example-label">{ex.label}</h3>

              <div className="example-sentences">
                <div className="example-s-box">
                  <span className="s-tag">A</span>
                  <p className="s-text">{ex.sentence1}</p>
                </div>
                <div className="example-s-box">
                  <span className="s-tag">B</span>
                  <p className="s-text">{ex.sentence2}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <p className="examples-disclaimer text-center">
          * Sample pairs are illustrative research examples designed to demonstrate temporal reasoning patterns.
        </p>
      </div>
    </section>
  );
}
