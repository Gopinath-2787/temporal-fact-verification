import React from 'react';
import { FileText, Cpu, BarChart3, ArrowRight } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      number: '01',
      title: 'Enter Statements',
      description: 'The user provides two statements (Statement A and Statement B) containing facts or events to compare.',
      icon: <FileText size={28} className="step-icon text-sky" />
    },
    {
      number: '02',
      title: 'Transformer Analysis',
      description: 'The fine-tuned RoBERTa transformer encodes the sentence pair jointly, mapping temporal cues and contextual semantic tokens.',
      icon: <Cpu size={28} className="step-icon text-violet" />
    },
    {
      number: '03',
      title: 'Relationship Prediction',
      description: 'The model classifies the pair into one of three relationship classes: Support, Neutral, or Invalidate with confidence probability.',
      icon: <BarChart3 size={28} className="step-icon text-emerald" />
    }
  ];

  return (
    <section id="how-it-works" className="how-it-works-section">
      <div className="app-container">
        
        <div className="section-header text-center">
          <span className="badge badge-cyan">PIPELINE OVERVIEW</span>
          <h2 className="section-title">How It Works</h2>
          <p className="section-subtitle">
            A three-stage transformer pipeline for temporal sequence reasoning and relationship classification.
          </p>
        </div>

        <div className="steps-container">
          {steps.map((step, idx) => (
            <React.Fragment key={step.number}>
              <div className="glass-panel step-card">
                <div className="step-top-row">
                  <span className="step-number-badge">{step.number}</span>
                  <div className="step-icon-wrapper">
                    {step.icon}
                  </div>
                </div>

                <h3 className="step-title">{step.title}</h3>
                <p className="step-description">{step.description}</p>
              </div>

              {idx < steps.length - 1 && (
                <div className="step-connector">
                  <ArrowRight size={20} className="connector-arrow" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>

      </div>
    </section>
  );
}
