import React from 'react';
import { ArrowRight, Sparkles, Clock, ShieldCheck, Layers } from 'lucide-react';

export default function HeroSection({ onStartClick }) {
  return (
    <section className="hero-section">
      <div className="hero-glow-bg" />
      <div className="app-container hero-container">
        
        {/* Research Tag */}
        <div className="hero-badge-wrapper">
          <span className="badge badge-cyan">
            <Sparkles size={13} className="inline-icon" />
            AI-POWERED RESEARCH PROTOTYPE
          </span>
        </div>

        {/* Main Title */}
        <h1 className="hero-title">
          Verify Facts. <span className="gradient-text">Understand Time.</span>
        </h1>

        {/* Subtitle */}
        <p className="hero-subtitle">
          Analyze relationships between two statements with transformer-based temporal fact verification.
        </p>

        {/* Short Explanation */}
        <p className="hero-description">
          Compare two claims and examine whether they support, contradict, or remain neutral toward one another based on temporal context and time-aware learned representations.
        </p>

        {/* Action Button */}
        <div className="hero-actions">
          <button onClick={onStartClick} className="btn btn-primary btn-large">
            Start Verification
            <ArrowRight size={18} />
          </button>
        </div>

        {/* Highlight Feature Badges */}
        <div className="hero-features-grid">
          <div className="hero-feature-card">
            <Clock className="feature-icon" size={20} />
            <div>
              <h4 className="feature-title">Time-Aware Analysis</h4>
              <p className="feature-desc">Detects temporal cues and chronological shifts between statements.</p>
            </div>
          </div>

          <div className="hero-feature-card">
            <Layers className="feature-icon" size={20} />
            <div>
              <h4 className="feature-title">RoBERTa Architecture</h4>
              <p className="feature-desc">Fine-tuned sequence classification for 3-class sentence pair reasoning.</p>
            </div>
          </div>

          <div className="hero-feature-card">
            <ShieldCheck className="feature-icon" size={20} />
            <div>
              <h4 className="feature-title">Probabilistic Outputs</h4>
              <p className="feature-desc">Delivers granular class probability distribution and confidence score.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
