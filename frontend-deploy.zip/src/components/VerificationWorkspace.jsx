import React from 'react';
import { ArrowLeftRight, Trash2, Zap, AlertCircle } from 'lucide-react';

export default function VerificationWorkspace({
  sentence1,
  setSentence1,
  sentence2,
  setSentence2,
  onVerify,
  onClear,
  onSwap,
  loading,
  error,
  apiOnline,
  modelLoaded,
}) {
  const MAX_CHAR = 2000;

  const handleSubmit = (e) => {
    e.preventDefault();
    onVerify();
  };

  const isFormInvalid = !sentence1.trim() || !sentence2.trim();

  return (
    <section id="workspace" className="workspace-section">
      <div className="app-container">
        
        <div className="glass-panel workspace-card">
          <div className="workspace-header">
            <div>
              <h2 className="workspace-title">Fact Verification Workspace</h2>
              <p className="workspace-subtitle">Enter two statements to analyze their temporal relationship.</p>
            </div>
            
            {/* Quick action buttons header */}
            <div className="workspace-header-actions">
              <button 
                type="button" 
                onClick={onSwap}
                disabled={loading || (!sentence1 && !sentence2)}
                className="btn btn-secondary btn-icon-text"
                title="Swap Statement A and Statement B"
              >
                <ArrowLeftRight size={16} />
                <span className="btn-text-desktop">Swap Statements</span>
              </button>

              <button 
                type="button" 
                onClick={onClear}
                disabled={loading || (!sentence1 && !sentence2)}
                className="btn btn-secondary btn-icon-text"
                title="Clear all text fields"
              >
                <Trash2 size={16} />
                <span className="btn-text-desktop">Clear All</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="workspace-form">
            
            {/* Input Grid */}
            <div className="statements-grid">
              
              {/* Statement A */}
              <div className="input-group">
                <div className="input-label-row">
                  <label htmlFor="statementA" className="input-label">STATEMENT A</label>
                  <span className="char-count">
                    {sentence1.length}/{MAX_CHAR}
                  </span>
                </div>
                <textarea
                  id="statementA"
                  className="statement-textarea"
                  placeholder="Enter the first statement (e.g., 'Ravi was the CEO of Acme Corp in 2020.')..."
                  value={sentence1}
                  maxLength={MAX_CHAR}
                  onChange={(e) => setSentence1(e.target.value)}
                  disabled={loading}
                  rows={5}
                />
              </div>

              {/* Statement B */}
              <div className="input-group">
                <div className="input-label-row">
                  <label htmlFor="statementB" className="input-label">STATEMENT B</label>
                  <span className="char-count">
                    {sentence2.length}/{MAX_CHAR}
                  </span>
                </div>
                <textarea
                  id="statementB"
                  className="statement-textarea"
                  placeholder="Enter the second statement (e.g., 'Priya took over as CEO of Acme Corp in 2025.')..."
                  value={sentence2}
                  maxLength={MAX_CHAR}
                  onChange={(e) => setSentence2(e.target.value)}
                  disabled={loading}
                  rows={5}
                />
              </div>

            </div>

            {/* Offline or Error Banner */}
            {!apiOnline && (
              <div className="alert-banner alert-warning">
                <AlertCircle size={18} className="alert-icon" />
                <div>
                  <strong>Backend API Disconnected:</strong> Make sure the Python FastAPI backend is running at <code className="code-inline">http://127.0.0.1:8000</code>.
                </div>
              </div>
            )}

            {apiOnline && !modelLoaded && (
              <div className="alert-banner alert-warning">
                <AlertCircle size={18} className="alert-icon" />
                <div>
                  <strong>Model Not Loaded:</strong> API server is online, but the trained RoBERTa checkpoint was not found at <code className="code-inline">models/roberta_best</code>.
                </div>
              </div>
            )}

            {error && (
              <div className="alert-banner alert-error">
                <AlertCircle size={18} className="alert-icon" />
                <div>
                  <strong>Verification Error:</strong> {error}
                </div>
              </div>
            )}

            {/* Form Controls */}
            <div className="form-actions-row">
              <button
                type="submit"
                disabled={loading || isFormInvalid || !apiOnline || !modelLoaded}
                className="btn btn-primary btn-verify"
              >
                {loading ? (
                  <>
                    <span className="spinner" />
                    <span>Analyzing statements...</span>
                  </>
                ) : (
                  <>
                    <Zap size={18} />
                    <span>Verify Relationship</span>
                  </>
                )}
              </button>
            </div>

          </form>
        </div>

      </div>
    </section>
  );
}
