import React, { useState } from 'react';
import { CheckCircle2, AlertTriangle, HelpCircle, Copy, Check, Info, Clock, Calendar, Zap, Layers, Sparkles } from 'lucide-react';

export default function PredictionResult({ result, onClearResult, onRetry }) {
  const [copied, setCopied] = useState(false);

  if (!result) return null;

  const { prediction, probabilities, confidence, model_architecture, temporal_analysis, sentence1, sentence2 } = result;

  // Format probabilities as percentages
  const probMap = {
    Invalidate: (probabilities?.Invalidate ?? 0) * 100,
    Neutral: (probabilities?.Neutral ?? 0) * 100,
    Support: (probabilities?.Support ?? 0) * 100,
  };

  const confidencePct = (confidence ? confidence * 100 : Math.max(...Object.values(probMap))).toFixed(1);

  // Styling and icons per predicted label
  const labelConfig = {
    Support: {
      colorClass: 'prediction-support',
      badgeClass: 'badge-support',
      icon: <CheckCircle2 size={26} className="icon-support" />,
      tagline: 'Statement B supports Statement A.',
      explanation: 'The Time-Aware RoBERTa model identified matching semantic and temporal contexts between the statements, concluding that Statement B reinforces the assertion in Statement A.'
    },
    Neutral: {
      colorClass: 'prediction-neutral',
      badgeClass: 'badge-neutral',
      icon: <HelpCircle size={26} className="icon-neutral" />,
      tagline: 'Statement B is neutral relative to Statement A.',
      explanation: 'The Time-Aware model detected no direct contradiction or explicit factual confirmation between the two statements. They describe distinct events or non-conflicting time periods.'
    },
    Invalidate: {
      colorClass: 'prediction-invalidate',
      badgeClass: 'badge-invalidate',
      icon: <AlertTriangle size={26} className="icon-invalidate" />,
      tagline: 'Statement B invalidates / contradicts Statement A.',
      explanation: 'The Time-Aware model identified a conflict in temporal assertions, negative cues, or mutually exclusive state changes between Statement A and Statement B.'
    }
  };

  const currentConfig = labelConfig[prediction] || labelConfig.Neutral;

  const handleCopy = () => {
    const textToCopy = `[Temporal AI Verification Result]
Model: ${model_architecture || 'Time-Aware Temporal RoBERTa'}
Prediction: ${prediction}
Confidence: ${confidencePct}%
Statement A: "${sentence1}"
Statement B: "${sentence2}"
Temporal Cues Extracted:
- Statement A: ${temporal_analysis?.statement1_cues?.join(', ') || 'None'}
- Statement B: ${temporal_analysis?.statement2_cues?.join(', ') || 'None'}
Class Probabilities:
- Invalidate: ${probMap.Invalidate.toFixed(1)}%
- Neutral: ${probMap.Neutral.toFixed(1)}%
- Support: ${probMap.Support.toFixed(1)}%`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="prediction-result-wrapper">
      <div className={`glass-panel prediction-card ${currentConfig.colorClass}`}>
        
        {/* Model Banner Tag */}
        <div className="model-architecture-banner">
          <span className="badge badge-cyan">
            <Sparkles size={12} className="inline-icon" />
            {model_architecture || 'Time-Aware Temporal RoBERTa (Feature Fusion)'}
          </span>
        </div>

        {/* Top Header */}
        <div className="prediction-card-header">
          <div className="prediction-main-label">
            <div className="label-icon-box">
              {currentConfig.icon}
            </div>
            <div>
              <span className="prediction-kicker">Predicted Temporal Relationship</span>
              <div className="prediction-title-row">
                <h3 className="prediction-title">{prediction}</h3>
                <span className={`badge ${currentConfig.badgeClass}`}>
                  {confidencePct}% Confidence
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="prediction-actions">
            <button 
              onClick={handleCopy} 
              className="btn btn-secondary btn-icon-text"
              title="Copy prediction summary to clipboard"
            >
              {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
              <span>{copied ? 'Copied!' : 'Copy Result'}</span>
            </button>
            <button 
              onClick={onClearResult} 
              className="btn btn-outline"
              title="Clear results and start new verification"
            >
              New Verification
            </button>
          </div>
        </div>

        {/* Explanation */}
        <div className="prediction-explanation-box">
          <p className="prediction-tagline">{currentConfig.tagline}</p>
          <p className="prediction-explanation">{currentConfig.explanation}</p>
        </div>

        {/* Temporal Cues Inspection Panel */}
        {temporal_analysis && (
          <div className="temporal-inspection-panel">
            <div className="inspection-header">
              <Clock size={16} className="text-cyan" />
              <h4 className="inspection-title">Extracted Temporal Feature Analysis</h4>
            </div>

            <div className="inspection-grid">
              <div className="inspection-card">
                <span className="inspection-label">Statement A Cues & Dates</span>
                <div className="cue-pills">
                  {temporal_analysis.statement1_cues?.length > 0 ? (
                    temporal_analysis.statement1_cues.map((cue, idx) => (
                      <span key={idx} className="cue-pill text-cyan-pill">{cue}</span>
                    ))
                  ) : (
                    <span className="no-cue">No explicit temporal tokens</span>
                  )}
                </div>
              </div>

              <div className="inspection-card">
                <span className="inspection-label">Statement B Cues & Dates</span>
                <div className="cue-pills">
                  {temporal_analysis.statement2_cues?.length > 0 ? (
                    temporal_analysis.statement2_cues.map((cue, idx) => (
                      <span key={idx} className="cue-pill text-violet-pill">{cue}</span>
                    ))
                  ) : (
                    <span className="no-cue">No explicit temporal tokens</span>
                  )}
                </div>
              </div>
            </div>

            <div className="feature-signals-row">
              <div className="signal-item">
                <span className="signal-label">Explicit Date Match:</span>
                <span className="signal-val">
                  {temporal_analysis.s1_has_date || temporal_analysis.s2_has_date ? 'Detected' : 'None'}
                </span>
              </div>

              <div className="signal-item">
                <span className="signal-label">Temporal Overlap:</span>
                <span className="signal-val">
                  {temporal_analysis.temporal_overlap ? 'True' : 'False'}
                </span>
              </div>

              <div className="signal-item">
                <span className="signal-label">Feature Vector Dim:</span>
                <span className="signal-val">10D Numerical Tensor</span>
              </div>
            </div>
          </div>
        )}

        {/* Probability Breakdown */}
        <div className="probability-breakdown">
          <h4 className="probability-heading">Model Class Probabilities</h4>
          <div className="probability-grid">
            
            {/* Invalidate Bar */}
            <div className="prob-item">
              <div className="prob-header">
                <span className="prob-name text-rose">Invalidate</span>
                <span className="prob-value">{probMap.Invalidate.toFixed(1)}%</span>
              </div>
              <div className="prob-track">
                <div 
                  className="prob-fill fill-rose" 
                  style={{ width: `${Math.min(100, Math.max(0, probMap.Invalidate))}%` }} 
                />
              </div>
            </div>

            {/* Neutral Bar */}
            <div className="prob-item">
              <div className="prob-header">
                <span className="prob-name text-sky">Neutral</span>
                <span className="prob-value">{probMap.Neutral.toFixed(1)}%</span>
              </div>
              <div className="prob-track">
                <div 
                  className="prob-fill fill-sky" 
                  style={{ width: `${Math.min(100, Math.max(0, probMap.Neutral))}%` }} 
                />
              </div>
            </div>

            {/* Support Bar */}
            <div className="prob-item">
              <div className="prob-header">
                <span className="prob-name text-emerald">Support</span>
                <span className="prob-value">{probMap.Support.toFixed(1)}%</span>
              </div>
              <div className="prob-track">
                <div 
                  className="prob-fill fill-emerald" 
                  style={{ width: `${Math.min(100, Math.max(0, probMap.Support))}%` }} 
                />
              </div>
            </div>

          </div>
        </div>

        {/* Original Statements Preview */}
        <div className="original-statements-box">
          <h4 className="statements-box-title">Analyzed Inputs</h4>
          <div className="statements-preview-grid">
            <div className="statement-preview-card">
              <span className="preview-label">STATEMENT A</span>
              <p className="preview-text">"{sentence1}"</p>
            </div>
            <div className="statement-preview-card">
              <span className="preview-label">STATEMENT B</span>
              <p className="preview-text">"{sentence2}"</p>
            </div>
          </div>
        </div>

        {/* Disclaimer Footer */}
        <div className="prediction-disclaimer">
          <Info size={14} className="disclaimer-icon" />
          <span>
            Note: Confidence represents the Time-Aware model's posterior probability, not an absolute guarantee of factual correctness. Research prototype output requires human verification.
          </span>
        </div>

      </div>
    </div>
  );
}
