const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');

/**
 * Check backend API health status.
 * @returns {Promise<{isOnline: boolean, modelLoaded: boolean, details?: object}>}
 */
export async function checkHealth() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/health`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      return { isOnline: false, modelLoaded: false, statusText: response.statusText };
    }

    const data = await response.json();
    return {
      isOnline: data.status === 'healthy',
      modelLoaded: Boolean(data.model_loaded),
      details: data,
    };
  } catch (error) {
    return {
      isOnline: false,
      modelLoaded: false,
      error: error.message,
    };
  }
}

/**
 * Predict temporal relationship between two statements.
 * @param {string} sentence1 
 * @param {string} sentence2 
 * @returns {Promise<{prediction: string, probabilities: Record<string, number>, confidence: number, sentence1: string, sentence2: string}>}
 */
export async function predictRelationship(sentence1, sentence2) {
  const payload = {
    sentence1: sentence1.trim(),
    sentence2: sentence2.trim(),
  };

  const response = await fetch(`${API_BASE_URL}/api/predict`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    let errorMessage = `Server error (${response.status})`;
    try {
      const errData = await response.json();
      if (errData.detail) {
        errorMessage = typeof errData.detail === 'string' ? errData.detail : JSON.stringify(errData.detail);
      }
    } catch {
      // fallback to status text
    }
    throw new Error(errorMessage);
  }

  const data = await response.json();
  return data;
}
