import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import VerificationWorkspace from './components/VerificationWorkspace';
import PredictionResult from './components/PredictionResult';
import ExampleGallery from './components/ExampleGallery';
import HowItWorks from './components/HowItWorks';
import ModelInfo from './components/ModelInfo';
import ResearchLimitations from './components/ResearchLimitations';
import Footer from './components/Footer';

import { checkHealth, predictRelationship } from './services/api';
import './App.css';

export default function App() {
  const [sentence1, setSentence1] = useState('');
  const [sentence2, setSentence2] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const [health, setHealth] = useState({
    isOnline: false,
    modelLoaded: false,
    error: null,
  });
  const [checkingHealth, setCheckingHealth] = useState(false);

  // Check backend health on mount
  const refreshHealth = async () => {
    setCheckingHealth(true);
    const status = await checkHealth();
    setHealth(status);
    setCheckingHealth(false);
  };

  useEffect(() => {
    refreshHealth();
    // Periodically ping health every 30s
    const interval = setInterval(refreshHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  // Handle Verification submit
  const handleVerify = async () => {
    if (!sentence1.trim() || !sentence2.trim()) {
      setError('Both Statement A and Statement B must contain valid text.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const data = await predictRelationship(sentence1, sentence2);
      setResult(data);
    } catch (err) {
      setError(err.message || 'Failed to analyze statements. Please check backend connection.');
    } finally {
      setLoading(false);
    }
  };

  // Swap Statement A and Statement B
  const handleSwap = () => {
    const temp = sentence1;
    setSentence1(sentence2);
    setSentence2(temp);
  };

  // Clear workspace inputs and output
  const handleClear = () => {
    setSentence1('');
    setSentence2('');
    setError(null);
    setResult(null);
  };

  // Populate inputs from Example Gallery
  const handleSelectExample = (s1, s2) => {
    setSentence1(s1);
    setSentence2(s2);
    setError(null);
    setResult(null);

    const workspaceEl = document.getElementById('workspace');
    if (workspaceEl) {
      workspaceEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="app-root">
      {/* Navigation */}
      <Navbar 
        health={health} 
        checkingHealth={checkingHealth} 
        onRefreshHealth={refreshHealth} 
      />

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <HeroSection 
          onStartClick={() => {
            const workspaceEl = document.getElementById('workspace');
            if (workspaceEl) {
              workspaceEl.scrollIntoView({ behavior: 'smooth' });
            }
          }}
        />

        {/* Verification Workspace */}
        <VerificationWorkspace 
          sentence1={sentence1}
          setSentence1={setSentence1}
          sentence2={sentence2}
          setSentence2={setSentence2}
          onVerify={handleVerify}
          onClear={handleClear}
          onSwap={handleSwap}
          loading={loading}
          error={error}
          apiOnline={health.isOnline}
          modelLoaded={health.modelLoaded}
        />

        {/* Prediction Results Panel (if available) */}
        {result && (
          <div className="app-container">
            <PredictionResult 
              result={result}
              onClearResult={() => setResult(null)}
              onRetry={handleVerify}
            />
          </div>
        )}

        {/* Example Pair Gallery */}
        <ExampleGallery onSelectExample={handleSelectExample} />

        {/* How It Works */}
        <HowItWorks />

        {/* Model & Research Benchmark Info */}
        <ModelInfo />

        {/* Research Limitations & Transparency */}
        <ResearchLimitations />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
